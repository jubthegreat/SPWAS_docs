/*
 * config.h
 *
 * Created: 14/09/2017 12:51:55
 *  Author: James
 */ 


#ifndef CONFIG_H_
#define CONFIG_H_

#include <avr/io.h>

// Pin Configuration

#define VOLTAGE_CHANNEL 0
#define CURRENT_CHANNEL 1

#define PARASITIC_LOAD_PORT PORTD
#define PARASITIC_LOAD_PIN PORTD4
#define PARASITIC_LOAD_DDR DDRD
#define PARASITIC_LOAD_DDB DDD4

#define POWER_SUPPLY_PORT PORTD
#define POWER_SUPPLY_PIN PORTD3
#define POWER_SUPPLY_DDR DDRD
#define POWER_SUPPLY_DDB DDD3

#define WAKE_UP_PORT PORTD
#define WAKE_UP_PIN PORTD2
#define WAKE_UP_DDR DDRD
#define WAKE_UP_DDB DDD2

#define LED_PORT PORTD
#define LED_PIN  PORTD5
#define LED_DDR  DDRD
#define LED_DDB  DDD5

#define SHORT_SENSE_PORT PORTC
#define SHORT_SENSE_PIN  PORTC3
#define SHORT_SENSE_DDR  DDRC
#define SHORT_SENSE_DDB  DDC3

#define PIN_DAC_SS	PORTC2
#define PORT_DAC_SS PORTC
#define DDR_DAC_SS  DDRC
#define DD_DAC_SS   DDC2

// Parameter Configuration

#define BANDGAP_REFERENCE 1.078f // Bandgap voltage magnitude / Volts
#define VOLTAGE_SCALE 2        // Voltage sense divider inverse ratio
#define SENSE_RESISTANCE 3.9f // Current sense resistor value / Ohms
#define LPF_GAIN 23.5f         // Measured LPF gain (op-amp gain * loading factor)

//#define RESISTANCE_SET_POINT 215.0f // Resistance set point / Ohms
#define RESISTANCE_SET_POINT 900.0f // Resistance set point / Ohms
//#define RESISTANCE_TOLERANCE 5      // Tolerance on MPPT algorithm / Ohms
#define RESISTANCE_TOLERANCE 20      // Tolerance on MPPT algorithm / Ohms
#define STEP_SIZE 1                 // DAC Code step size

#define FREQUENCY_LOW 100    // Frequency underspeed value
#define FREQUENCY_HIGH 600 // Frequency overspeed value

// Uncomment the line below to enable current offset removal
// #define SHORT_SENSE

#endif /* CONFIG_H_ */