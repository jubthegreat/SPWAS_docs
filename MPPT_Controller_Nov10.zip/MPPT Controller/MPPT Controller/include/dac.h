/*
 * dac.h
 *
 * Created: 11/09/2017 14:58:57
 *  Author: James
 */ 

#ifndef DAC_H_
#define DAC_H_

#include <stdint.h>

void dac_init(void);
void dac_sleep(void);
void write_dac_a(uint16_t code);
void write_dac_b(uint16_t code);

#endif /* DAC_H_ */