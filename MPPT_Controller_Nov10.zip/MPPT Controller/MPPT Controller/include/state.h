/*
 * state.h
 *
 * Created: 14/09/2017 13:34:15
 *  Author: James
 */ 


#ifndef STATE_H_
#define STATE_H_

typedef struct {
    
} state_t;

#endif /* STATE_H_ */