/*
 * adc.h
 *
 * Created: 14/09/2017 17:04:19
 *  Author: James
 */ 


#ifndef ADC_H_
#define ADC_H_

void adc_enable(void);
void adc_disable(void);

void adc_init(void);
uint16_t adc_read(uint8_t pin);

#endif /* ADC_H_ */