/*
 * sleep.h
 *
 * Created: 12/09/2017 17:03:10
 *  Author: James
 */ 


#ifndef SLEEP_H_
#define SLEEP_H_

void deep_sleep_2s(void);
void induce_coma(void);

#endif /* SLEEP_H_ */