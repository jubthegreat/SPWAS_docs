#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>


#ifndef BAUD
#define BAUD 300
#endif
#include <util/setbaud.h>

void uart_init(void);
void uart_putchar(char c, FILE *stream);
char uart_getchar(FILE *stream);
