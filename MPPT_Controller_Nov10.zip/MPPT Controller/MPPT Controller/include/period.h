/*
 * frequency.h
 *
 * Created: 13/09/2017 11:29:57
 *  Author: James
 */ 


#ifndef PERIOD_H_
#define PERIOD_H_

uint16_t get_period(void);

#endif /* PERIOD_H_ */