/*
 * mppt.h
 *
 * Created: 14/09/2017 12:57:29
 *  Author: James
 */ 


#ifndef MPPT_H_
#define MPPT_H_

void mppt_max();
void mppt_min();

void mppt_optimise();
float measure_resistance();

#endif /* MPPT_H_ */