/*
 * pin.h
 *
 * Created: 12/09/2017 16:17:49
 *  Author: James
 */ 


#ifndef BIT_H_
#define BIT_H_

#define PORT_(port)	PORT ## port
#define	DDR_(port)	DDR ## port
#define PIN_(port)  PIN ## port

#define PORT(port)	PORT_(port)
#define DDR(port)	DDR_(port)
#define PIN(port)	PIN_(port)

#endif /* BIT_H_ */