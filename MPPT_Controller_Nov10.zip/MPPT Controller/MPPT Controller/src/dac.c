/*
 * dac.c
 *
 * Created: 11/09/2017 14:59:54
 *  Author: James
 */ 
#define F_CPU 120000

#include <avr/io.h>
#include <util/delay.h>

#include "dac.h"
#include "spi.h"
#include "config.h"

void dac_init(void) {
    spi_init();
    DDR_DAC_SS |= (1<<DD_DAC_SS);
    PORT_DAC_SS |= (1<<PIN_DAC_SS);	// Set SS high (N.B.: SS is active low)
}

void dac_sleep(void) {
    
    // Buffer to hold command
    uint8_t output[2];
    
    // Construct command to send to DAC	
    output[0] = (0xF << 4);
    output[1] = 0;
    
    // Send the command via SPI
    PORT_DAC_SS &= ~(1 << PIN_DAC_SS);
    spi_transmit_sync(output, 2);
    PORT_DAC_SS |= (1 << PIN_DAC_SS);    
}

void write_dac_a(uint16_t code) {
    
    // Buffer to hold command
    uint8_t output[2];
    
    // Construct command to send to DAC	
    output[1] = (0x3F & code) << 2;
    output[0] = (0x9 << 4) | ((code >> 6) & 0xF);
    
    // Send the command via SPI
    PORT_DAC_SS &= ~(1 << PIN_DAC_SS);
    spi_transmit_sync(output, 2);
    PORT_DAC_SS |= (1 << PIN_DAC_SS);
}

void write_dac_b(uint16_t code) {
    
    // Buffer to hold command
    uint8_t output[2];
    
    // Construct command to send to DAC
    output[1] = (0x3F & code) << 2;
    output[0] = (0xA << 4) | ((code >> 6) & 0xF);
    
    // Send the command via SPI
    PORT_DAC_SS &= ~(1 << PIN_DAC_SS);
    spi_transmit_sync(output, 2);
    PORT_DAC_SS |= (1 << PIN_DAC_SS);
}