/*
 * period.c
 *
 * Created: 13/09/2017 12:07:45
 *  Author: James
 */ 

// TODO: Try and optimise this a bit

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/power.h>

uint16_t temp;

volatile uint8_t capture_complete;
volatile uint16_t capture_start_value;
volatile uint16_t capture_end_value;

#include "period.h"
#include "config.h"

 uint16_t get_period(void) {
    cli();
    ACSR = (0 << ACD) | (0 << ACIE) | (1 << ACIC);
    
    power_timer1_enable();
    
    // Normal Mode
    TCCR1A = 0;
    // ICES1 = Capture on Positive Edge
    // CS10  = Clock Source 1 (CPU Clock)
    TCCR1B = (1 << ICES1) | (1 << CS10);
    // Reset timer value
    TCNT1 = 0;
    // Clear interrupt flags
    TIFR1 |= (1 << ICF1) | (1 << TOV1);
    // Enable interrupts
    TIMSK1 |= (1 << ICIE1) | (1 << TOIE1);
    
    capture_complete = 0;
    
    sei();
    
    while (capture_complete != 2);
    
    cli();
    ACSR |= (1 << ACD);
    power_timer1_disable();
    
    return (capture_end_value - capture_start_value);
 }
 
 
 // TODO: Fix this latency.
 // An array based storage method may be superior
 ISR(TIMER1_CAPT_vect) {
     temp = ICR1;
     if (capture_complete == 0) {
        capture_start_value = temp;
        capture_complete++;
     }
     else if (capture_complete == 1) {
        //ACSR &= ~(1 << ACIC);
          
        capture_end_value = temp;
        capture_complete++;
        TIMSK1 &= ~((1 << ICIE1) | (1 << TOIE1)); 
     }
 }
 
 ISR(TIMER1_OVF_vect) {
     capture_complete = 2;
     capture_start_value = 0;
     capture_end_value = 65535;
     TIMSK1 &= ~((1 << ICIE1) | (1 << TOIE1));
 }