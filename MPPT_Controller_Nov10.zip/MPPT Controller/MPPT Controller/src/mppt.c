/*
 * mppt.c
 *
 * Created: 14/09/2017 13:11:18
 *  Author: James
 */

#define F_CPU 120000UL

#include <stdint.h>
#include <math.h>
#include <util/delay.h>

#include "config.h"
#include "dac.h"
#include "adc.h"

static uint16_t mppt_output;

void mppt_max() {
    write_dac_a(1023);
    mppt_output = 1023;
}

void mppt_min() {
    write_dac_a(0);
    mppt_output = 0;
}

void short_sense_enable() {
    SHORT_SENSE_PORT |= (1 << SHORT_SENSE_PIN);
}

void short_sense_disable() {
    SHORT_SENSE_PORT &= ~(1 << SHORT_SENSE_PIN);
}

float measure_resistance() {
    float current;
    float voltage;
    
    #ifdef SHORT_SENSE
    short_sense_enable(); // Short out the current sense resistor
    float current_offset = adc_read(1) * BANDGAP_REFERENCE / 1024.0f; // Measure the offset // was adc_read(0) in JP version
    short_sense_disable(); // Remove the short
    #endif // SHORT_SENSE
            
    // Calculate the actual voltages at the ADC pins
    current = adc_read(1) * BANDGAP_REFERENCE / 1024.0f;	//was adc_read(0) in JP version
    voltage = adc_read(0) * BANDGAP_REFERENCE / 1024.0f;	//was adc_read(1) in JP version
            
    #ifdef SHORT_SENSE
    float current -= current_offset; // Subtract the measured offset from the current measurement
    #endif // SHORT_SENSE
            
    // Scale the voltage according to the potential divider (1000 factor may improve numerical stability)
    voltage = voltage * VOLTAGE_SCALE * 1000;
            
    // Scale the current according to the sense resistance and LPF gain (1000 factor may improve numerical stability)
    current = current / SENSE_RESISTANCE / LPF_GAIN * 1000;
            
    return voltage / current;
}

void mppt_optimise() {
    adc_enable();
	int i;
	i=0;
    // Initialise to allow for first tolerance comparison
    float resistance = measure_resistance();
    
    while ((fabs(resistance - RESISTANCE_SET_POINT) > RESISTANCE_TOLERANCE) && i<500) {

        if (resistance < RESISTANCE_SET_POINT) {
            // The load is too high; increase the MPPT reference voltage
            // Overflow protection
            if (mppt_output < (1024 - STEP_SIZE)) {
                mppt_output += STEP_SIZE;
                write_dac_a(mppt_output);
            }                
        }
        else if (resistance > RESISTANCE_SET_POINT) {
            // The load is too low; decrease the MPPT reference voltage
            // Overflow protection
            if (mppt_output >= STEP_SIZE) {
                mppt_output -= STEP_SIZE;
                write_dac_a(mppt_output);
            }            
        }
        
        resistance = measure_resistance();
		i++;
    }
    
    adc_disable();
}