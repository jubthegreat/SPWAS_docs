/*
* mppt_controller.c
*
* Created: 11/09/2017 12:01:19
*  Author: James
*/

#define F_CPU 120000UL

#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h> //For UART


//#include <stdint.h>
#include <avr/interrupt.h>
#include <avr/power.h>



#include "config.h"
#include "adc.h"
#include "dac.h"
#include "mppt.h"
#include "sleep.h"
#include "wd.h"
#include "period.h"

#ifndef BAUD
#define BAUD 300
#endif
#include <util/setbaud.h>



void uart_init(void) {
	UBRR0H = UBRRH_VALUE;
	UBRR0L = UBRRL_VALUE;
	
	#if USE_2X
	UCSR0A |= _BV(U2X0);
	#else
	UCSR0A &= ~(_BV(U2X0));
	#endif

	UCSR0C = _BV(UCSZ01) | _BV(UCSZ00); /* 8-bit data */
	UCSR0B = _BV(RXEN0) | _BV(TXEN0);   /* Enable RX and TX */
}

void uart_putchar(char c, FILE *stream) {
	if (c == '\n') {
		uart_putchar('\r', stream);
	}
	loop_until_bit_is_set(UCSR0A, UDRE0);
	UDR0 = c;
}

char uart_getchar(FILE *stream) {
	loop_until_bit_is_set(UCSR0A, RXC0);
	return UDR0;
}

void blink1(void){
	// Flash the LED
	LED_PORT |=  (1 << LED_PIN);
	_delay_ms(100);
	LED_PORT &= ~(1 << LED_PIN);
	_delay_ms(100);
}
uint16_t get_raw_voltage(){
	adc_enable();
	uint16_t raw_voltage;
	raw_voltage = adc_read(0);  // was adc_read(1) in JP version
	//voltage = raw_voltage * BANDGAP_REFERENCE / 1024.0f;
	adc_disable();
	return(raw_voltage);
}
uint16_t get_raw_current(){
	adc_enable();
	uint16_t raw_current;
	raw_current = adc_read(1);  // was adc_read(0) in JP version
	// Note: Doesn't compensate for shortsense
	//current = raw_current * BANDGAP_REFERENCE / 1024.0f;
	adc_disable();
	return(raw_current);
}

void transmitData(uint16_t freq, uint16_t curr, uint16_t volt){
	char data[] = "##ffccvv@@";
	char freqLo = freq & 0xFF;
	char freqHi = freq >> 8;
	char currLo = curr & 0xFF;
	char currHi = curr >> 8;
	char voltLo = volt & 0xFF;
	char voltHi = volt >> 8;
	
	data[2] = freqHi;
	data[3] = freqLo;
	data[4] = currHi;
	data[5] = currLo;
	data[6] = voltHi;
	data[7] = voltLo;
	puts(data);
	// assemble at the other end as -->  uint16_t value = lo | uint16_t(hi) << 8;	
}
void transmitBigData(uint16_t freq, uint16_t raw_curr, uint16_t raw_volt){
	char str[80];
	float current;
	float voltage;
	current = raw_curr * BANDGAP_REFERENCE / 1024.0f;
	current = current / SENSE_RESISTANCE / LPF_GAIN * 1000;
	
	voltage = raw_volt * BANDGAP_REFERENCE / 1024.0f;
	voltage = voltage * VOLTAGE_SCALE * 1000;
	
	int currInt1 = current;                  // Get the integer
	float currFrac = current - currInt1;      // Get fraction 
	int currInt2 = trunc(currFrac * 10000);  // Turn into integer
	
	int voltInt1 = voltage;                  // Get the integer
	float voltFrac = voltage - voltInt1;      // Get fraction
	int voltInt2 = trunc(voltFrac * 10000);  // Turn into integer 
	
	//int str_len = sprintf(str, "F:%d C:%f V:%f", freq, current, voltage);
	int str_len = sprintf(str, "F:%d Cr:%d Vr:%d Cf:%d.%04d Vf:%d.%04d\n", freq, raw_curr, raw_volt, currInt1, currInt2, voltInt1, voltInt2);
	puts(str);
}

FILE uart_output = FDEV_SETUP_STREAM(uart_putchar, NULL, _FDEV_SETUP_WRITE);
FILE uart_input = FDEV_SETUP_STREAM(NULL, uart_getchar, _FDEV_SETUP_READ);

void activate_load(void) {
    PARASITIC_LOAD_PORT |= (1 << PARASITIC_LOAD_PIN);
}

void deactivate_load(void) {
    PARASITIC_LOAD_PORT &= ~(1 << PARASITIC_LOAD_PIN);
}

void activate_rectifier(void) {
    POWER_SUPPLY_PORT |= (1 << POWER_SUPPLY_PIN);
}

void deactivate_rectifier(void) {
    POWER_SUPPLY_PORT &= ~(1 << POWER_SUPPLY_PIN);
}

/*
* wdt_init(void)
*
* Required to reset watchdog on system reset.
* Even though watchdog not used for reset in
* this application, a memory glitch or other
* error could result in the watchdog reset
* being enabled, causing a reset loop.
*
* The "function" runs on system reset prior
* to main() being called.
*
*/
void wdt_init(void) __attribute__((naked)) __attribute__((section(".init3")));

void wdt_init(void) {
    MCUSR = 0;
    WD_DISABLE();
}

void initialise() {
    cli(); // Disable interrupts - should only be enabled when actually needed
    
    dac_init(); // Initialise DAC
    adc_init(); // Initialise ADC
	
    
    //// Power down everything
    power_twi_disable();
    power_timer0_disable();
    power_timer1_disable();
    power_timer2_disable();
    //power_usart0_disable();
    adc_disable(); // Power down the ADC
    
    // Disable the digital input buffers on the analogue comparator pins
    DIDR1 |= (1 << AIN1D) | (1 << AIN0D);
    
    //// Disable the digital input buffers on the ADC pins in use
    DIDR0 |= (1 << ADC0D) | (1 << ADC1D);
    
    //// Set data direction for output pins
	// AH 09.11.17: these should all be OR operations? first two just had "="
    POWER_SUPPLY_DDR |= (1 << POWER_SUPPLY_DDB);
    PARASITIC_LOAD_DDR |= (1 << PARASITIC_LOAD_DDB);
    LED_DDR |= (1 << LED_DDB);
    SHORT_SENSE_DDR |= (1 << SHORT_SENSE_DDB);
    
    // Setup the wake interrupt
    // ISC00 = INT0 triggered by any level change
    EICRA |= (1 << ISC00);
    
    deactivate_rectifier();
    deactivate_load();
    
    mppt_max(); // Set bq25505 load to zero
    
    // Flash the LED
    LED_PORT |=  (1 << LED_PIN);
    _delay_ms(10);
    LED_PORT &= ~(1 << LED_PIN);
}


int main(void) {
	
    uart_init();
    stdout = &uart_output;
    stdin  = &uart_input;
	uint16_t rawCurrent;
	uint16_t rawVoltage;
	
    uint16_t frequency;
    
    initialise();
    
    while (1) {
      //puts("ccccccccccccccccccccccc");
	  //blink1();
	  
		frequency = F_CPU/get_period();
		rawCurrent = get_raw_current();
		rawVoltage = get_raw_voltage();
		
		transmitBigData(frequency, rawCurrent, rawVoltage);
		//transmitData(frequency, rawCurrent, rawVoltage);
		//transmitData(16706,17220,17477); //For debug purposes sends ##ABCDDE@@
      
	    
		//For Hardware Debug purposes
        // If frequency is outside desired range
		//*
        /// AH 09.11.17 why is this while statement needed?
		//while ((frequency < FREQUENCY_LOW) || (frequency > FREQUENCY_HIGH)) {
            
            // Turbine stalled - power down active components
            if (frequency < FREQUENCY_LOW) {
				 //puts("low");
                deactivate_rectifier(); // Power down rectifier
                dac_sleep(); // Power down DAC
                
                EIMSK |= (1 << INT0); // Enable wakeup interrupt
                induce_coma(); 
                
                // Restarts here
                EIMSK |= (1 << INT0); // Disable wakeup interrupt
            }
            
            else if (frequency > FREQUENCY_HIGH) {
				//puts("high");
                activate_load(); // Switch in parasitic load
                deactivate_rectifier(); // Power down rectifier
                dac_sleep(); // Power down DAC
                
                // Sleep for two seconds
                //deep_sleep_2s();
				// AH 09.11.17 changed from sleep to delay to test theory about UART issue
                _delay_ms(2000);
                //Restarts here
                deactivate_load(); // Remove parasitic load
            }
            
            // Get a fresh frequency measurement
			//AH 09.11.17 commented out as can't see why needed
            //frequency = F_CPU/get_period();
      
		//}
		//*/
		
		
        //puts("normal");
		
        // Frequency OK
        activate_rectifier(); // Power up rectifier
        
		
		//For Hardware Debug purposes, commented out
        mppt_optimise(); // Run MPPT algorithm
        
		LED_PORT |=  (1 << LED_PIN);
		_delay_ms(50);
		LED_PORT &= ~(1 << LED_PIN);
			
        deep_sleep_2s();
		// _delay_ms(2000);
		
    }
}

ISR(INT0_vect) {
    // Don't do anything - this is only used to wake from a coma
}


