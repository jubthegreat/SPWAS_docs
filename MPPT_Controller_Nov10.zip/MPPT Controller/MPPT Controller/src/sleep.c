/*
 * sleep.c
 *
 * Created: 12/09/2017 17:04:05
 *  Author: James
 */ 

#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <util/atomic.h>

#include "sleep.h"
#include "wd.h"

void deep_sleep_2s(void) {
    WD_SET(WD_IRQ, WDTO_2S);
    set_sleep_mode(SLEEP_MODE_PWR_DOWN);
    
    NONATOMIC_BLOCK(NONATOMIC_RESTORESTATE) {
        sleep_mode();
    }
    
    WD_SET(WD_OFF);
}

void induce_coma(void) {
    set_sleep_mode(SLEEP_MODE_PWR_DOWN);
    
    NONATOMIC_BLOCK(NONATOMIC_RESTORESTATE) {
        sleep_mode();	
    }
}

ISR(WDT_vect) {
    // Don't do anything
}