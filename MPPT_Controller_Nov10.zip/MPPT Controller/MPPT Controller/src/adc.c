/*
 * adc.c
 *
 * Created: 14/09/2017 17:06:11
 *  Author: James
 */

#include <avr/power.h>

#include "adc.h"

void adc_init(void) {
    ADMUX |= (1 << REFS0) | (1 << REFS1); // Use bandgap reference as AVREF
}

void adc_enable(void) {
    power_adc_enable(); // Turn on the ADC clock
    ADCSRA |= (1 << ADEN); // Enable the ADC
}

void adc_disable(void) {
    ADCSRA &= ~(1 << ADEN); // Disable the ADC
    power_adc_disable(); // Turn off the ADC clock
}

uint16_t adc_read(uint8_t pin) {
    uint16_t result; // Variable for result of conversion
    uint16_t result_low; // Variable for low result of conversion
    uint16_t result_high; // Variable for high result of conversion
    
    ADMUX = (ADMUX & 0xF0) | (pin & 0x7); // Set the ADC pin
    ADCSRA |= (1 << ADSC); // Start the conversion
    
    while ((ADCSRA & (1 << ADSC)) != 0); // Wait for conversion to finish
    
    result_low = ADCL;
    result_high = ADCH;
   
    result = (result_high << 8) | result_low;
    
    return result;
}